<?php

include 'config.php';

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Function to filter products based on category
function getProductsByCategory($category) {
    global $conn;

    $category = $conn->real_escape_string($category);

    $sql = "SELECT * FROM product WHERE category = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $category);
    $stmt->execute();

    $result = $stmt->get_result();

    $products = array();

    while ($row = $result->fetch_assoc()) {
        $products[] = array(
            'name' => $row['name'],
            'image_link' => $row['imagelink'],
            'category' => $row['category'],
            'subCategory' => $row['sub_category'],
            'description' => $row['description'],
            'quantity' => $row['quantity'],
            'price' => $row['price']
        );
    }

    $stmt->close();

    return $products;
}

// Get category name from the API request
if (isset($_GET['category'])) {
    $category = $_GET['category'];

    // Call the function to get products based on the category
    $filteredProducts = getProductsByCategory($category);

    // Output JSON response
    header('Content-Type: application/json');
    echo json_encode($filteredProducts);
} else {
    // If category is not provided, return an error message
    echo json_encode(array('error' => 'Category parameter is missing.'));
}

// Close the database connection
$conn->close();
?>
