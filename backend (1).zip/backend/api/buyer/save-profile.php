<?php

include 'config.php';

// Check if the connection is successful
if ($conn->connect_error) {
    http_response_code(500);
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Function to insert a new record into the buyer table
function insertUID($uid, $name, $gstn, $email, $contactNumber, $address, $city, $state, $latitude, $longitude)
{
    global $conn;

    // Insert new record using prepared statement
    $sql = "INSERT INTO buyer (uid, name, gstn, email, contactNumber, address, city, state, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssss", $uid, $name, $gstn, $email, $contactNumber, $address, $city, $state, $latitude, $longitude);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Successfully created account"]);
    } else {
        echo json_encode(["error" => "Error creating account"]);
    }
}

// Check if the required GET parameters are set
if (isset($_GET['uid'], $_GET['name'])) {
    $uid = $_GET['uid'];
    $name = $_GET['name'];
    $gstn = $_GET['gstn'] ?? '';
    $email = $_GET['email'] ?? '';
    $contactNumber = $_GET['contactNumber'] ?? '';
    $address = $_GET['address'] ?? '';
    $city = $_GET['city'] ?? '';
    $state = $_GET['state'] ?? '';
    $latitude = $_GET['latitude'] ?? '';
    $longitude = $_GET['longitude'] ?? '';

    insertUID($uid, $name, $gstn, $email, $contactNumber, $address, $city, $state, $latitude, $longitude);
} else {
    echo json_encode(["error" => "UID or name not provided"]);
}

// Close the database connection
$conn->close();
?>
