<?php
include 'config.php';

function buyProduct($buyer_uid, $seller_uid, $product_id, $conn) {
    // Check if buyer, seller, and product exist
    $buyer_result = getUserData($conn, 'buyer', $buyer_uid);
    $seller_result = getUserData($conn, 'seller', $seller_uid);

    if (!$buyer_result || !$seller_result) {
        return "User(s) not found!";
    }

    $buyer = $buyer_result->fetch_assoc();
    $seller = $seller_result->fetch_assoc();

    // Check if buyer has enough credits
    if ($buyer['credits'] < 200) {
        return "Insufficient credits!";
    }

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Update credits for buyer and seller
        updateCredits($conn, 'buyer', $buyer_uid, $buyer['credits'] - 200);
        updateCredits($conn, 'seller', $seller_uid, $seller['credits'] + 200);

        // Update product status to 'sold'
        updateProductStatus($conn, $product_id);

        // Commit transaction
        $conn->commit();
        return "Transaction successful!";
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        return "Transaction failed: " . $e->getMessage();
    }
}

function getUserData($conn, $userType, $uid) {
    $query = $conn->prepare("SELECT * FROM $userType WHERE uid = ?");
    $query->bind_param("s", $uid);
    $query->execute();
    return $query->get_result();
}

function updateCredits($conn, $userType, $uid, $updated_credits) {
    $update_query = $conn->prepare("UPDATE $userType SET credits = ? WHERE uid = ?");
    $update_query->bind_param("is", $updated_credits, $uid);
    $update_query->execute();
}

function updateProductStatus($conn, $product_id) {
    $update_query = $conn->prepare("UPDATE product SET status = 'sold' WHERE id = ?");
    $update_query->bind_param("i", $product_id);
    $update_query->execute();
}

// Example usage
$buyer_uid = $_GET['buyeruid'] ?? null;
$seller_uid = $_GET['selleruid'] ?? null;
$product_id = $_GET['productid'] ?? null;

$result = buyProduct($buyer_uid, $seller_uid, $product_id, $conn);
echo $result;

// Close connection
$conn->close();
?>
