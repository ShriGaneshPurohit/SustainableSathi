<?php
    // Include the configuration file
    include 'config.php';
    
    // Function to add a product to the database
    function addProduct($conn, $name, $imageLink, $category, $description, $quantity, $price, $sellerUID, $city, $state) {
        // Use prepared statements to prevent SQL injection
        $sql = $conn->prepare("INSERT INTO product (name, imagelink, category, description, quantity, price, sellerUID, city, state) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $sql->bind_param("ssssddsss", $name, $imageLink, $category, $description, $quantity, $price, $sellerUID, $city, $state);
        
        if ($sql->execute()) {
            echo "Data inserted successfully";
        } else {
            echo "Error: " . $sql->error;
        }

        // Close the statement
        $sql->close();
    }
    
    if (isset($_GET['sellerUID'])){
        // Retrieve form data without sanitization (consider using filtering and validation)
        $name = $_GET['name'];
        $imageLink = $_GET['imageLink'];
        $category = $_GET['category'];
        $description = $_GET['description'];
        $quantity = $_GET['quantity'];
        $price = $_GET['price'];
        $sellerUID = $_GET['sellerUID'];
        $city = $_GET['city'];
        $state = $_GET['state'];
    
        if ($conn->connect_error) {
            die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
        }
    
        // Call the function to add the product to the database
        addProduct($conn, $name, $imageLink, $category, $description, $quantity, $price, $sellerUID, $city, $state);
    
        // Close the database connection
        $conn->close();
    }
?>
