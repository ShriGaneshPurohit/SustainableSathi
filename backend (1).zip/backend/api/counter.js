var count = document.getElementsByClassName("count");
var inc = [];

function intervalFunc() {
    for (let i = 0; i < count.length; i++) {
        inc.push(1);
        if (inc[i] != count[i].getAttribute("max-data")) {
            inc[i]++;
        }  
        if (i === 2) {
            count[i].innerHTML = inc[i] + "<span>%</span>";
        } else {   
            count[i].innerHTML = inc[i] + "<span> lac. </span>";
        }
    }
}

setInterval(intervalFunc, 100);