<?php

include 'config.php';

// Check if the connection is successful
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Function to check if a record with given UID and name already exists
function recordExists($uid, $name)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM seller WHERE uid = ? AND name = ?");
    $stmt->bind_param("ss", $uid, $name);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Function to insert a new record into the seller table
function insertUID($uid, $name, $age, $email, $contactNumber, $address, $city, $state, $latitude, $longitude)
{
    global $conn;

    // Check if the record already exists
    if (recordExists($uid, $name)) {
        echo json_encode(["message" => "Account already exists"]);
        return;
    }

    // Insert new record
    $stmt = $conn->prepare("INSERT INTO seller (uid, name, age, email, contactNumber, address, city, state, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssss", $uid, $name, $age, $email, $contactNumber, $address, $city, $state, $latitude, $longitude);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Successfully created account"]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
}

// Check if the required POST parameters are set
if (isset($_POST['uid'], $_POST['name'])) {
    $uid = $_POST['uid'];
    $name = $_POST['name'];
    $age = $_POST['age'] ?? '';
    $email = $_POST['email'] ?? '';
    $contactNumber = $_POST['contactNumber'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $latitude = $_POST['latitude'] ?? '';
    $longitude = $_POST['longitude'] ?? '';

    // Insert the record
    insertUID($uid, $name, $age, $email, $contactNumber, $address, $city, $state, $latitude, $longitude);
} else {
    echo json_encode(["error" => "UID or name not provided"]);
}

// Close the database connection
$conn->close();

?>
