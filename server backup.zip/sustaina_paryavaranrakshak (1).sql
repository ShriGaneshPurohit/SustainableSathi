-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 12, 2024 at 04:52 PM
-- Server version: 8.0.35
-- PHP Version: 8.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sustaina_paryavaranrakshak`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int NOT NULL,
  `name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(2, 'Apple'),
(9, 'Asus'),
(14, 'Benq'),
(8, 'Dell'),
(10, 'HP'),
(3, 'LG'),
(5, 'Oppo'),
(7, 'Poco'),
(12, 'Realme'),
(13, 'Redmi'),
(1, 'Samsung'),
(11, 'Sony'),
(6, 'Vivo'),
(4, 'Xiaomi');

-- --------------------------------------------------------

--
-- Table structure for table `buyer`
--

CREATE TABLE `buyer` (
  `id` int NOT NULL,
  `uid` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `gstn` varchar(200) NOT NULL,
  `email` varchar(300) NOT NULL,
  `contactNumber` varchar(11) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `longitude` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `latitude` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `credits` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `buyer`
--

INSERT INTO `buyer` (`id`, `uid`, `name`, `gstn`, `email`, `contactNumber`, `address`, `city`, `state`, `longitude`, `latitude`, `credits`) VALUES
(1, 'bSK8jIUiWBUzK8FFI6CiWu99NtB2', 'Fire Frame', 'twrwy', 'help.fireframe@gmail.com', 'twts', 'tets', 'test', 'tets', '74.3821285', '16.7426027', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Mobile`
--

CREATE TABLE `Mobile` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` int NOT NULL,
  `brand` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Mobile`
--

INSERT INTO `Mobile` (`id`, `name`, `price`, `brand`) VALUES
(1, 'S24', 80000, 'Samsung'),
(2, 'Iphone 15 Ultra', 149900, 'Apple'),
(3, 'F23 5G', 22999, 'Samsung'),
(4, 'Iphone SE', 39900, 'Apple'),
(5, 'Iphone X', 91900, 'Apple');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int NOT NULL,
  `name` varchar(500) NOT NULL,
  `imagelink` varchar(800) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `category` varchar(500) NOT NULL,
  `sub_category` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `quantity` int NOT NULL,
  `price` float NOT NULL,
  `sellerUID` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `imagelink`, `category`, `sub_category`, `description`, `quantity`, `price`, `sellerUID`, `city`, `state`, `status`) VALUES
(1, 'twst', 'https://img.freepik.com/premium-photo/modern-smartphone-with-large-broken-screen-with-debris-grunge-backgdound-with-copy-space_222464-1567.jpg', 'Mobile', 'Category 3', 'tsts', 55, 124, 'IE45sFO3yPOnsg7zaoa9IUMVYO22', 'test', 'test', 'sold'),
(2, 'Testidue', 'https://firebasestorage.googleapis.com/v0/b/sustainable-sathi.appspot.com/o/productsImg%2FThu%20Feb%2001%2021%3A48%3A31%20GMT%2B05%3A30%202024?alt=media&token=e8471b63-d0a1-4ed3-ad09-f95c039b11da', 'AC', 'Category 3', 'Theus is sia o', 3, 2800, 'IE45sFO3yPOnsg7zaoa9IUMVYO22', 'test', 'test', 'available'),
(3, 'Laptop', 'https://firebasestorage.googleapis.com/v0/b/sustainable-sathi.appspot.com/o/productsImg%2FThu%20Feb%2001%2021%3A48%3A31%20GMT%2B05%3A30%202024%2FThu%20Feb%2001%2021%3A49%3A02%20GMT%2B05%3A30%202024?alt=media&token=a4bdac7b-bdde-459d-a01e-f25dc03f6116', 'Laptop', 'Category 1', 'Theus is sia o', 1, 28000, 'IE45sFO3yPOnsg7zaoa9IUMVYO22', 'test', 'test', 'available'),
(4, 'yehd', 'https://firebasestorage.googleapis.com/v0/b/sustainable-sathi.appspot.com/o/productsImg%2FMon%20Feb%2012%2010%3A15%3A11%20GMT%2B05%3A30%202024?alt=media&token=b16fddfb-5c7c-4c4d-a813-e168b0d5b728', 'Category 1', 'Category 1', 'fyr', 2, 21, 'bSK8jIUiWBUzK8FFI6CiWu99NtB2', 'test', 'test', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `Refrigerator`
--

CREATE TABLE `Refrigerator` (
  `id` int NOT NULL,
  `capacityLiters` int NOT NULL,
  `brand` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `id` int NOT NULL,
  `uid` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `age` int NOT NULL,
  `email` varchar(300) NOT NULL,
  `contactNumber` varchar(11) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `longitude` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `latitude` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `credits` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`id`, `uid`, `name`, `age`, `email`, `contactNumber`, `address`, `city`, `state`, `longitude`, `latitude`, `credits`) VALUES
(1, 'J4UrZlbNn2MxyGOYAi4oysvfVDD3', 'Manav Patni', 23, 'mnvpatni@gmail.com', '1234567890', 'test ', 'test', 'test', '74.42864214060414', '16.68877946107986', 0);

-- --------------------------------------------------------

--
-- Table structure for table `SolarPanel`
--

CREATE TABLE `SolarPanel` (
  `id` int NOT NULL,
  `model` varchar(255) NOT NULL,
  `capacityWatts` int NOT NULL,
  `brand` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `TV`
--

CREATE TABLE `TV` (
  `id` int NOT NULL,
  `model` varchar(255) NOT NULL,
  `screenSizeInches` decimal(5,2) NOT NULL,
  `brand` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `verified_facility`
--

CREATE TABLE `verified_facility` (
  `id` int NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `latitude` varchar(100) NOT NULL,
  `longitude` varchar(100) NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `contactNumber` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `verified_facility`
--

INSERT INTO `verified_facility` (`id`, `name`, `address`, `city`, `state`, `latitude`, `longitude`, `email`, `contactNumber`) VALUES
(1, 'Mahesh Trader', 'Mahesh Traders Plot No. 316, Shree Shahu \r\nMarket Yard, Tal. Karveer, Dist. Kolhapur', 'Kolhapur', 'Maharashtra', '16.7074231', '74.2599560', 'maheshtrade@gmail.com', '9823901011'),
(2, 'Trekomac Refurbs Pvt. Ltd.', ' Plot No, G-3, Five Star MIDC Kagal Hatkanangale, Tal. Kagal, Dist. \r\nKolhapur', 'Kolhapur', 'Maharashtra', '16.635608', '74.355920', 'refurbstrekomac@gmail.com', '8652658017'),
(3, 'CPG Shell Mould & Casting', 'CPG Shell Mould & Casting, Plot No. W-\r\n39, Additional MIDC, Satara', 'Satara', 'Maharashtra', '19.195161', '73.196894', 'cpgshell@gmail.com', '9822777706'),
(4, 'Hi-Tech Recycling (I) Pvt. Ltd', 'Property No.193, Gat No. 89, Pune-Satara Road, \r\nShindewadi, Tal: Bhor, Dist:- Pune', 'Pune', 'Maharashtra', '18.491851', '73.857820', 'manish@hitechrecycling.in', '9860602601'),
(5, 'Pranam Enterprises', 'Pranam Enterprises, Sr. No. 286/116, Next to Badhe, Vill. Urali Deveshi, Tal. \r\nHaveli, Dist. Pune', 'Pune', 'Maharashtra', '18.489619', '74.141305', 'pranamenterprises@yahoo.co.in', '9850333853'),
(6, 'AG Enterprises', 'AG Enterprises,\r\nGat No. 815 (1), Kudalwadi, Chikhli, Pune 411062', 'Pune', 'Maharashtra', '18.665307', '73.813235', 'agpune57@gmail.com', '9822783051'),
(7, 'Ambar Enterprises', 'Ambar Enterprises\r\nAwutade, Handewadi, Tal. Haveli, Dist. Pune 411028', 'Pune', 'Maharashtra', '18.696337', '73.793099', 'ambarent028@gmail.com', '9890812746'),
(8, 'Anand computer system', 'Anand Computer System\r\n2160 B, Sadashiv Peth, Swamipuram Bldg, Shop No. 7,8,9, \r\nPune - 411030', 'Pune', 'Maharashtra', '18.504093', '73.848158', '--', '937015373'),
(9, 'Arsh Recycle pvt. ltd.', 'GAT No. 1750, RANJANGAON GANPATI, PUNE \r\nNAGAR ROAD, Ranjangaon Ganpati, Pune - 412209', 'Pune', 'Maharashtra', '18.755187', '74.244907', 'arshrecycling4@gmail.com', '7040691499'),
(10, 'BKE Recycling', 'BKE RECYCLING\r\nAdsul Mala, Shivram Nagar,Uruli Devachi,URULI \r\nDEVACHI,Pune - 412308', 'Pune', 'Maharashtra', '18.464744', '73.952981', '--', '9764279786'),
(11, 'Eco Tantra LLP', 'Eco Tantra LLP\r\nM-365, Raviwar Peth, Bohari Lane, Tal. & Dist. Pune', 'Pune', 'Maharashtra', '18.474041', '73.795027', 'richa@ecotantra.in', '8981473653'),
(12, 'E-Waste Global', 'Gate No. 2, Near Theur Phata, Lonikand, Pune Nagar \r\nRoad, Tal. Haveli, Dist. Pune 412216', 'Pune', 'Maharashtra', '18.555900', '73.963896', 'ewastegbl@gmail.com', '9833587530'),
(13, 'Green Enviro Services', 'Green Enviro Services,\r\n118/1, Wasali, Tal. Khed, Dist. Pune', 'Pune', 'Maharashtra', '19.631726', '73.730146', 'greenenviropune@gmail.com', '9892859959'),
(14, 'Green IT Recycling Center', 'Green IT Recycling Center Pvt Ltd\r\nPlot No. D-222, MIDC Ranjangaon, Dist.- Pune - 412209', 'Pune', 'Maharashtra', '18.512776', '73.848720', 'rth_raj@hotmail.com', '9822356062'),
(15, 'Green Tech Solution Industries', 'Green Tech Solution Industries\r\nGat No. 83/1, A/p. Wakhari, tal. Pandharpur, Dist. Solapur \r\n413304', 'Solapur', 'Maharashtra', '17.696375', '75.256396', 'gtsgroup.pune@gmai.com', '9096084671'),
(16, 'Greenscape Eco Management Private Limited\r\n', 'Greenscape Eco Management Private Limited\r\nMIDC Chakan Industrial Area (Ph-II), Pune - 410501', 'Pune', 'Maharashtra', '18.762403', '73.863149', 'rupesh@greenscape-eco.com', '7558426313'),
(17, 'Harshita Green Recyclers', 'Harshita Green Recyclers,\r\nGat No. 452, Urse Talegaon Dhabade, Tal. Maval, Dist. \r\nPune', 'Pune', 'Maharashtra', '18.707213', '73.643784', 'harshitagreenrecyclers@gmail.com', '9850205186'),
(18, 'J.S. Enterprises', 'J.S.Enterprises\r\nGat No-132, Khalumbre, Chakan - 410501', 'Pune', 'Maharashtra', '18.623351', '73.800088', 'jsenterprises21@gmail.com', '9921280827'),
(19, 'Kuldeep E-Waste Disposals', 'Sr. No. 50, Waghjainagar, Mabegaon Khurd, Katraj-\r\nAmbegaon Road, Katraj, Pune - 411046', 'Pune', 'Maharashtra', '18.448474', '73.856001', 'sagarscrap@gmail.com', '9850289885'),
(20, 'Mahalaxmi E- Recyclers Pvt. Ltd.', 'Plot NO.77 & 78, Subplot No. 3A, Ramtekde Industrial Area, Hadapsar, Tal. Haveli, Dist. Pune', 'Pune', 'Maharashtra', '18.497216', '73.915240', 'mpmehta_2000@yahoo.com', '9850349580'),
(21, 'M/s. Veera Waste Management Systems', 'Plot No. 42, Block-D Extension, IDA, Autonagar\r\nVisakhapatnam District.-530012', 'Vishakapatnam', 'Andra Pradesh', '17.699960', '83.186801', '--', '--'),
(22, 'M/s. United Global Trust', ' F-5, Zoo Road, Senduri Ali Path, Guwahati, Dist. Kamrup (M) \r\nAssam', 'Kamrup', 'Assam', '26.180537', '91.774350', '--', '--'),
(23, 'M/s. ADV Metal Combine Pvt. Ltd.', 'Shed No. - 25, Borai Industrial Growth Center, Rasmada, \r\nDist.- Durg (C.G)', 'Durg', 'Chhattisgarh', '21.248159', '81.192316', '--', '--'),
(24, 'M/s Muskan Technologies', 'M/s Muskan Technologies, B-96,Okhla \r\nIndustrial Area,Phase-1,Delhi- 110020', 'Delhi', 'Delhi', '28.522766', '77.282288', '--', '--'),
(25, 'M/s. Earth E-Waste Management Pvt. Ltd.', 'Block No. 63, Sagun Ind. Estate, Type-A Paiky \r\n11-A & 10-D, Vill-Altodara, Tal. Opad', 'Surat', 'Gujrat', '21.325470', '72.839577', '--', '--'),
(26, 'M/s Global E Waste Management Systems ', 'Plot No: Shop No 729/s-1 to 729/s-5 , Sonum \r\nTownship Nessai Salcete – Goa', 'Margao', 'Goa', '15.269448370423998', '74.00312117866653', '--', '7798001629'),
(27, 'M/s. Exigo Recycling (P) Ltd.', 'M/s. Exigo Recycling (P) Ltd., Barsat Road, \r\nPanipat', 'Panipat', 'Haryana', '29.426031', '76.992981', '--', '--'),
(28, 'M/s Global Waste Solution', 'M/s Global Waste Solution, Village Ram Nagar, \r\nTehsil Ganaur, Distt. Sonipat', 'Sonipat', 'Haryana', '29.086835', '77.082665', '--', '--'),
(29, 'M/s. Cerebra Integrated Technologies Ltd.', 'Plot No. 41 to 46, Appasandra village, KIADB \r\nIndl. Area, Narasapura Hobli', 'Hubli', 'Karnatak', '13.112731', '77.983611', '--', '--'),
(30, 'M/s. Kerala Enviro Infrastructure Ltd', 'Infrastructure Ltd E Waste Dismantling Facility, Common TSDF project, Inside Fact -CD Campus', 'Kochi', 'Kerala', '9.982154', '76.362903', '--', '-'),
(31, 'ECO Friend Industries', 'Plot No. A-205, TTC Industrial Area, MIDC Pawane, Navi Mumbai, Tal. & Dist. Thane', 'Thane, Mumbai', 'Maharashtra', '19.092004', '73.026746', 'ingle.mamata@raoagroup.com', '9821151069'),
(32, 'Threco Recycling LLP', 'Threco Recycling LLP, Survey No. 153-3 & 149-1, Hedavli, Dist- Raigad', 'Raigad', 'Maharashtra', '19.134631', '72.836862', 'karan@threco.com', '9820622802'),
(33, 'Techeco E-Waste Namo LLP', 'Gat No. 155 B/2, Village Dhakambe, Tal. Dindori, Dist. Nashik', 'Nashik', 'Maharashtra', '20.103196', '73.813973', 'techeco123@gmail.com', '9769117070'),
(34, 'Evergreen Recyclekaro India Pvt. Ltd.', 'Gut. No. 113/A, Village Pali, \r\nTal. Wada, Dist. Palghar', 'Palghar', 'Maharashtra', '19.637890', '73.130184', 'rajesh@recyclekaro.com', '9967310007'),
(35, 'Arihant E Recycling Pvt Ltd', 'Arihant E Recycling Pvt Ltd, Gut No.307/1, Shahada Road, Dondaicha, Tal-Sinkheda, Dist-Dhule.', 'Dhule', 'Maharashtra', '21.324512', '74.556387', 'info@arihantinfo.com', '9820350406'),
(36, 'Avis Technoways\r\n', 'Avis Technoways, Plot No. A-58, MIDC Osmanabad, Dist. Osmanabad', 'Osmanabad', 'Maharashtra', '18.221068', '76.039473', 'avis.tech@rediffmail.com', '9420737679'),
(37, 'Baban Plastic', 'Baban Plastic, Gut No. 1, At. Sajapur, Tal. & Dist. Aurangabad 401136', 'Aurangabad', 'Maharashtra', '19.872657', '75.222504', 'acc.babanplastic@gmail.com', '9923299786'),
(38, 'M/s. Moonstar Enterprises Pvt. Ltd', 'Plot No.24/A, 24/D, 24/A -1, 21/D, 21/E, 21/E -1, Sector -B, Sanwer Road, Industrial Area ', 'Indore', 'Madhya Pradesh', '22.764336', '75.846885', '--', '-'),
(39, 'M/s Greenscape Eco Management Pvt.', 'M/s Greenscape Eco Management Pvt.(Unt-II), F-588 & 591 MIA Alwar', 'Alwar', 'Rajasthan', '27.554808', '76.640611', '--', '--'),
(40, 'M/s Circularity Solutions PrivateLimited ', 'Khasra 95-96, Village - Sikhera,Hazazari Industrial Area, Modinagar, Ghaziabad', 'Ghaziabad', 'Uttar Pradesh', '28.749462', '77.943209', '--', '--');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `buyer`
--
ALTER TABLE `buyer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Mobile`
--
ALTER TABLE `Mobile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `brandName` (`brand`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Refrigerator`
--
ALTER TABLE `Refrigerator`
  ADD PRIMARY KEY (`id`),
  ADD KEY `brandName` (`brand`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `SolarPanel`
--
ALTER TABLE `SolarPanel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `brandName` (`brand`);

--
-- Indexes for table `TV`
--
ALTER TABLE `TV`
  ADD PRIMARY KEY (`id`),
  ADD KEY `brandName` (`brand`);

--
-- Indexes for table `verified_facility`
--
ALTER TABLE `verified_facility`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `buyer`
--
ALTER TABLE `buyer`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `Mobile`
--
ALTER TABLE `Mobile`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Refrigerator`
--
ALTER TABLE `Refrigerator`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `SolarPanel`
--
ALTER TABLE `SolarPanel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `TV`
--
ALTER TABLE `TV`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `verified_facility`
--
ALTER TABLE `verified_facility`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Mobile`
--
ALTER TABLE `Mobile`
  ADD CONSTRAINT `Mobile_ibfk_1` FOREIGN KEY (`brand`) REFERENCES `brands` (`name`);

--
-- Constraints for table `Refrigerator`
--
ALTER TABLE `Refrigerator`
  ADD CONSTRAINT `Refrigerator_ibfk_1` FOREIGN KEY (`brand`) REFERENCES `brands` (`name`);

--
-- Constraints for table `SolarPanel`
--
ALTER TABLE `SolarPanel`
  ADD CONSTRAINT `SolarPanel_ibfk_1` FOREIGN KEY (`brand`) REFERENCES `brands` (`name`);

--
-- Constraints for table `TV`
--
ALTER TABLE `TV`
  ADD CONSTRAINT `TV_ibfk_1` FOREIGN KEY (`brand`) REFERENCES `brands` (`name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
