<?php

include 'config.php';

// Check if the connection is successful
if ($conn->connect_error) {
    http_response_code(500);
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Function to check if a record with given UID and name already exists
function recordExistsBuyer($uid, $name)
{
    global $conn;
    $sql = "SELECT * FROM buyer WHERE uid = ? AND name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $uid, $name);
    $stmt->execute();
    $result = $stmt->get_result();

    return $result->num_rows > 0;
}

function recordExistsSeller($uid, $name)
{
    global $conn;
    $sql = "SELECT * FROM seller WHERE uid = ? AND name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $uid, $name);
    $stmt->execute();
    $result = $stmt->get_result();

    return $result->num_rows > 0;
}


// Check if the required GET parameters are set
if (isset($_GET['uid'], $_GET['name'])) {
    $uid = $_GET['uid'];
    $name = $_GET['name'];

    if (recordExistsBuyer($uid, $name)) {
        echo json_encode(["message" => "Buyer"]);
    }else if(recordExistsSeller($uid, $name)) {
        echo json_encode(["message" => "Seller"]);
    } else {
        echo json_encode(["message" => "Record does not exist"]);
    }
} else {
    echo json_encode(["error" => "UID or name not provided"]);
}

// Close the database connection
$conn->close();
?>