<?php

include 'config.php';

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Function to filter products based on category
function getProductsByCategory($category) {
    global $conn;
    
    $category = $conn->real_escape_string($category);
    
    $sql = "SELECT * FROM products WHERE category = '$category'";
    $result = $conn->query($sql);

    $products = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $products[] = array(
            'name' => $product['name'],
            'image_link' => $product['imagelink'],
            'category' => $product['category'],
            'subCategory' => $product['sub_category'],
            'description' => $product['description'],
            'quantity' => $product['quantity'],
            'price' => $product['price']
            );
        }
    }

    return $products;
}

// Get category name from the API request
if (isset($_GET['category'])) {
    $category = $_GET['category'];

    // Call the function to get products based on the category
    $filteredProducts = getProductsByCategory($category);

    // Output JSON response
    header('Content-Type: application/json');
    echo json_encode($filteredProducts);
} else {
    // If category is not provided, return an error message
    echo json_encode(array('error' => 'Category parameter is missing.'));
}

// Close the database connection
$conn->close();
?>
