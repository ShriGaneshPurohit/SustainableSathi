<?php
// Include database configuration
include 'config.php';

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// User input from API
$state = $_GET['state']; 
$city = $_GET['city'];   

// SQL query
$sql = "SELECT category, COUNT(*) AS count, SUM(quantity) AS total_quantity
        FROM product 
        WHERE state = ? AND city = ?
        GROUP BY category
        ORDER BY count DESC";

// Prepare and bind the SQL statement
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $state, $city);

// Execute the query
$stmt->execute();

// Get result
$result = $stmt->get_result();

// Fetch data and store in an array
$data = array();
while ($row = $result->fetch_assoc()) {
    // Multiply quantity with count and add to the result array
    $row['total'] = $row['count'] * $row['total_quantity'];
    $data[] = $row;
}

// Close statement and connection
$stmt->close();
$conn->close();

// Output result in JSON format
header('Content-Type: application/json');
echo json_encode($data);

?>