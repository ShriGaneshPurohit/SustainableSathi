<?php
include 'config.php';

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Assuming the buyer UID is passed as a parameter in the URL
$buyer_uid = $_GET['uid'] ?? null;

if (!$buyer_uid) {
    die(json_encode(["error" => "Buyer UID is missing."]));
}

// Fetch city information of the buyer
$buyer_query = "SELECT city FROM buyer WHERE uid = '$buyer_uid'";
$buyer_result = $conn->query($buyer_query);

// Initialize response array
$response = [];

$buyer_city = $buyer_result->fetch_assoc()['city'];

// Fetch products details in the same city as the buyer
$product_query = "SELECT * FROM product WHERE city = '$buyer_city'";
$product_result = $conn->query($product_query);

if ($product_result->num_rows > 0) {
    while ($product = $product_result->fetch_assoc()){
        $response[] = [
            'name' => $product['name'],
            'image_link' => $product['imagelink'],
            'category' => $product['category'],
            'subCategory' => $product['sub_category'],
            'description' => $product['description'],
            'quantity' => $product['quantity'],
            'price' => $product['price']
        ];
    }
} else {
    $response['error'] = "No matching products found in the buyer's city.";
}


// Convert the response array to JSON
$json_response = json_encode($response);

echo $json_response;

// Close the connections
$buyer_query->close();
$product_query->close();
$conn->close();
?>
