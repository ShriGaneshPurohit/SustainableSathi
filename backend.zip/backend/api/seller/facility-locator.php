<?php

// Include database configuration
include 'config.php';

// Check database connection
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Function to calculate Haversine distance
function haversineDistance($lat1, $lon1, $lat2, $lon2) {
    $earthRadius = 6371; // Radius of the Earth in kilometers

    $latDiff = deg2rad($lat2 - $lat1);
    $lonDiff = deg2rad($lon2 - $lon1);

    $a = sin($latDiff / 2) * sin($latDiff / 2) +
        cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
        sin($lonDiff / 2) * sin($lonDiff / 2);

    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

    $distance = $earthRadius * $c; // Distance in kilometers

    return round($distance, 2); // Round off to 2 decimal places
}

// Check if UID is provided
if (isset($_GET['uid'])) {
    // UID is provided, get seller's coordinates from the database
    $sellerUid = $_GET['uid'];
    $sqlSeller = "SELECT uid, latitude, longitude FROM seller WHERE uid = '$sellerUid'";
    $resultSeller = $conn->query($sqlSeller);

    if ($resultSeller->num_rows > 0) {
        $sellerData = $resultSeller->fetch_assoc();
        $sellerLatitude = $sellerData['latitude'];
        $sellerLongitude = $sellerData['longitude'];

        // Query buyers from the database
        $sqlBuyer = "SELECT uid, name, contactNumber, latitude, longitude FROM buyer";
        $resultBuyer = $conn->query($sqlBuyer);

        if ($resultBuyer->num_rows > 0) {
            $nearbyBuyers = [];

            while ($row = $resultBuyer->fetch_assoc()) {
                $distance = haversineDistance($sellerLatitude, $sellerLongitude, $row['latitude'], $row['longitude']);

                if ($distance <= 200) { // Within 200km radius
                    $nearbyBuyers[] = [
                        'uid' => $row['uid'],
                        'name' => $row['name'],
                        'contactNumber' => $row['contactNumber'],
                        'latitude' => $row['latitude'],
                        'longitude' => $row['longitude'],
                        'distance' => round($distance, 2),
                    ];
                }
            }

            if (!empty($nearbyBuyers)) {
                // Return JSON response for the nearby buyers
                echo json_encode($nearbyBuyers, JSON_PRETTY_PRINT);
            } else {
                // No nearby buyers found
                echo json_encode(['message' => 'No nearby buyers found within 200km radius'], JSON_PRETTY_PRINT);
            }
        } else {
            // No buyers in the database
            echo json_encode(['message' => 'No buyers in the database'], JSON_PRETTY_PRINT);
        }
    } else {
        // Seller not found in the database
        echo json_encode(['message' => 'Seller not found in the database'], JSON_PRETTY_PRINT);
    }
} else {
    // UID not provided
    echo json_encode(['error' => 'Seller UID not provided. Please provide a valid UID.'], JSON_PRETTY_PRINT);
}

// Close the database connection
$conn->close();

?>
