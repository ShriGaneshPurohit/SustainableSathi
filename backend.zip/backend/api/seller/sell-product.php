<?php
    // Include the configuration file
    include 'config.php';
    
    // Function to add a product to the database
    function addProduct($conn, $name, $imageLink, $category, $subCategory, $description, $quantity, $price, $sellerUID, $city, $state) {
        // SQL query to insert product data into the 'product' table
        $sql = "INSERT INTO product (name, imagelink, category, sub_category, description, quantity, price, sellerUID, city, state) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssiisss", $name, $imageLink, $category, $subCategory, $description, $quantity, $price, $sellerUID, $city, $state);
    
        if ($stmt->execute()) {
            echo "Product added successfully";
        } else {
            echo "Error: " . $stmt->error;
        }
    
        // Close the statement
        $stmt->close();
    }
    
    if (isset($_POST['sellerUID'])){
        // Check if the form is submitted
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve form data without sanitization
            $name = $_POST['name'];
            $imageLink = $_POST['imageLink'];
            $category = $_POST['category'];
            $subCategory = $_POST['subCategory'];
            $description = $_POST['description'];
            $quantity = $_POST['quantity'];
            $price = $_POST['price'];
            $sellerUID = $_POST['sellerUID'];
            $city = $_POST['city'];
            $state = $_POST['state'];
    
            if ($conn->connect_error) {
                die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
            }
    
            // Call the function to add the product to the database
            addProduct($conn, $name, $imageLink, $category, $subCategory, $description, $quantity, $price, $sellerUID, $city, $state);
    
            // Close the database connection
            $conn->close();
        }
    }
?>
