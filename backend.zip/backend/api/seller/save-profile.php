<?php

include 'config.php';

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

function recordExists($uid, $name)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM seller WHERE uid = ? AND name = ?");
    $stmt->bind_param("ss", $uid, $name);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

function insertUID($uid, $name, $age, $email, $contactNumber, $address, $city, $state)
{
    global $conn;

    if (recordExists($uid, $name)) {
        echo json_encode(["message" => "Account already exists"]);
        return;
    }

    $stmt = $conn->prepare("INSERT INTO seller (uid, name, age, email, contactNumber, address, city, state) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $uid, $name, $age, $email, $contactNumber, $address, $city, $state);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Successfully created account"]);
    } else {
        echo json_encode(["error" => "Error: " . $stmt->error]);
    }
}

if (isset($_POST['uid'], $_POST['name'])) {
    $uid = $_POST['uid'];
    $name = $_POST['name'];
    $age = $_POST['age'] ?? '';
    $email = $_POST['email'] ?? '';
    $contactNumber = $_POST['contactNumber'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';

    insertUID($uid, $name, $age, $email, $contactNumber, $address, $city, $state);
} else {
    echo json_encode(["error" => "UID or name not provided"]);
}

$conn->close();

?>