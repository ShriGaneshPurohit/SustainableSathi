<?php

$server_name = "localhost";
$db_user = "sustaina_paryavaranrakshak";
$db_pass = "Rakshak@1";
$db_name = "sustaina_paryavaranrakshak";

// Create connection
$conn = mysqli_connect($server_name, $db_user, $db_pass, $db_name); 

?>

